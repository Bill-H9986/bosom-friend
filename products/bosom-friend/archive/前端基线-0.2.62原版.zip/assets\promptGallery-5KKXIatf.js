const t={title1:"디지털 코드 폭포 속의 인간 실루엣",title2:"재에서 부활하는 불꽃 피닉스",title3:"우주선이 성간 웜홀을 통과",title4:"비 오는 밤에 칼을 뽑는 사이버 사무라이",item1:`모델: Veo 3.1 Fast
길이: 6초
해상도: 720 × 1280 (9:16 세로)

장면: 디지털 코드 폭포 속의 인간 실루엣

첫 프레임/커버 요구사항:
- 위에서 쏟아지는 녹색 코드 스트림
- 중앙에 선명한 인간 윤곽, 하이테크 미학

타임라인:
- 0-1초: 위에서 쏟아지는 빽빽한 녹색 코드 비
- 1-3초: 코드 스트림 속에서 인간 실루엣이 서서히 나타나고, 코드가 그 주위를 흐름
- 3-5초: 인물이 눈을 뜨고 (파란 빛 방출), 손을 뻗어 코드를 터치
- 5-6초: 코드가 터치된 곳에서 빛이 폭발하며 바깥으로 퍼지고, 페이드 아웃

효과: 매트릭스 코드 비, 홀로그램 스캔 라인, 데이터 파티클, 레이트레이싱 반사
배경: 순수한 검은 공간, 코드 빛만 존재
스타일: 매트릭스 미학, 검정-녹색 색상 스킴, 하이테크 텍스처
카메라: 정면 고정, 약간 줌인`,item2:`모델: Veo 3.1 Fast
길이: 6초
해상도: 720 × 1280 (9:16 세로)

장면: 재에서 부활하는 불꽃 피닉스

첫 프레임/커버 요구사항:
- 피닉스 실루엣이 중앙에, 불꽃 파티클로 둘러싸임
- 어두운 배경이 불빛과 대비, 강한 시각적 임팩트

타임라인:
- 0-1초: 어둠 속에서 재가 쌓이고, 희미한 잔불이 깜빡임
- 1-3초: 불꽃이 갑자기 폭발하고, 피닉스 윤곽이 서서히 형성
- 3-5초: 피닉스가 날개를 완전히 펼치고, 불꽃 깃털이 흩어지며, 파티클이 튐
- 5-6초: 피닉스가 날아오르고, 불꽃 꼬리가 뒤따르며, 카메라가 위로 이동하고 페이드 아웃

효과: 불꽃 파티클, 떨어지는 잔불, 열파로 인한 공기 왜곡, 다이나믹 라이팅
배경: 순수한 검은 심연, 불빛으로만 밝혀짐
스타일: 에픽 CG, 오렌지-레드-골드 톤, 시네마틱 라이팅
카메라: 낮은 각도로 위를 바라보며, 천천히 위로 패닝`,item3:`모델: Veo 3.1 Fast
길이: 6초
해상도: 1280 × 720 (16:9 가로)

장면: 우주선이 성간 웜홀을 통과

첫 프레임/커버 요구사항:
- 우주선이 중앙에, 웜홀 링으로 둘러싸임
- 장엄한 별밭 배경, 충격적인 구도

타임라인:
- 0-1초: 우주선이 거대한 웜홀 입구 앞에 떠 있고, 에너지 소용돌이가 회전
- 1-3초: 우주선 엔진 점화, 웜홀로 돌진, 시공간이 왜곡되기 시작
- 3-5초: 통과하는 동안, 다채로운 빛 줄기가 고속으로 지나가고, 성운이 늘어나며 변형
- 5-6초: 우주선이 반대편에서 나타나고, 새로운 은하를 마주하며, 페이드 아웃

효과: 에너지 소용돌이, 광속 스트레치 효과, 시공간 왜곡, 엔진 트레일, 성운 파티클
배경: 심우주 성운, 먼 은하들, 웜홀 에너지 링
스타일: 인터스텔라/스타워즈 미학, 웅장한 에픽 느낌, HDR 하이 다이나믹 레인지
카메라: 우주선을 따라가며, 정지에서 고속 가속으로`,item4:`모델: Veo 3.1 Fast
길이: 6초
해상도: 1280 × 720 (16:9 가로)

장면: 비 오는 밤에 칼을 뽑는 사이버 사무라이

첫 프레임/커버 요구사항:
- 사무라이가 옆으로 서서, 손은 칼자루에
- 갑옷에 네온 조명 반사, 공중에 정지된 빗방울

타임라인:
- 0-1초: 비 오는 밤거리, 사무라이가 카메라에 등을 지고 서 있고, 네온 조명 깜빡임
- 1-2초: 사무라이가 갑자기 돌아서며, 칼자루를 잡음 (슬로우 모션)
- 2-4초: 칼집에서 칼을 뽑고, 칼빛이 빗줄기를 가르며, 빗방울을 자름 (슈퍼 슬로우 모션)
- 4-5초: 칼이 칼집으로 돌아가고, 빗방울이 다시 떨어지기 시작
- 5-6초: 사무라이가 돌아서서 걸어가며, 비안개 속으로 사라지고, 페이드 아웃

효과: 칼빛 궤적, 잘린 빗방울 디테일, 슬로우 모션 비, 네온 반사, 증기 안개
배경: 사이버펑크 일본 거리, 네온 간판, 젖은 바닥 반사
스타일: 데빌 메이 크라이/사이버펑크 사무라이 미학, 시안-퍼플 네온 색상, 시네마틱 슬로우 모션
카메라: 미디엄 사이드 샷, 타격 시 정면 클로즈업으로 전환`},n="🎨 프롬프트 영감 라이브러리",e="추천 예시",s="빠른 창작 시작",i="추천 예시를 탐색하고, 원클릭으로 창작을 시작하세요",l="지금 적용",o="접기",a="더 보기",c="항목",d="✓ 프롬프트 적용됨",r="모두 로드됨",p="프롬프트",m="일치하는 프롬프트를 찾을 수 없습니다",g="다른 키워드로 검색해 보세요",u={promptLabel:"프롬프트:",applyButton:"지금 적용"},h={edit:"편집",generate:"텍스트에서 이미지로"},y={all:"전체",recommend:"추천",image:"이미지 생성"},b={all:"전체",generate:"텍스트에서 이미지로",edit:"이미지 편집",searchPlaceholder:"제목 검색..."},f="적용",T={title:"Zhiyin 주요 기능",subtitle:"서명 기능, 원클릭으로",platforms:"지원 플랫폼",helperTitle:"한 줄 게시",helperExample:'예: "길거리 음식"에 대한 이미지를 유화 스타일로 생성하고 Instagram 게시 시간 추천',categories:{contentGeneration:"콘텐츠 생성",editing:"편집 & 후처리",localization:"현지화 & 최적화",publishing:"게시 & 배포",automation:"자동화",analytics:"분석 & 인사이트",interaction:"참여 & 운영"},items:{inspiration:{title:"창작 영감",desc:"계정 특성과 트렌드에서 주제 아이디어 및 창작 템플릿 생성"},oneClickScript:{title:"원클릭 스크립트",desc:"키워드나 프롬프트에서 짧은 동영상/글 스크립트 및 스토리보드 상세 자동 생성"},multiTemplates:{title:"다중 스타일 템플릿",desc:"원클릭 전환이 가능한 여러 동영상 및 카피 스타일 템플릿 제공"},imageGenerate:{title:"이미지 생성",desc:"프롬프트에서 고품질 이미지 생성, 다중 스타일 및 출력 지원"},videoGenerate:{title:"동영상 생성",desc:"스크립트나 프롬프트에서 음악 및 장면 제안을 포함한 짧은 동영상 초안 제작"},highlight:{title:"하이라이트 편집",desc:"고에너지 순간을 자동 감지하고 템플릿을 사용하여 하이라이트 클립 생성"},storyboard:{title:"스토리보드 디자인",desc:"타임라인, 대화 및 촬영 체크리스트 자동 생성, 내보내기 지원"},coverSuggestion:{title:"표지 & 썸네일",desc:"여러 표지 옵션 생성 및 클릭 최적화 썸네일 제안"},download:{title:"자산 다운로드 & 변환",desc:"플랫폼 동영상 가져오기, 여러 해상도로 일괄 다운로드 및 형식 변환"},videoTranslation:{title:"동영상 번역",desc:"얼굴 수준 립싱크, 음성 복제 및 내장/소프트 자막 내보내기 지원"},platformAdapt:{title:"플랫폼 적응",desc:"대상 플랫폼 규칙에 맞게 카피 길이, 페이싱 및 형식 자동 조정"},topicTag:{title:"주제 & 태그 추천",desc:"트렌드 및 계정 기록에 기반한 고가치 주제 및 태그 추천"},seo:{title:"SEO & 키워드 최적화",desc:"카피 및 설명에 대한 검색 및 발견 최적화 제안 제공"},schedule:{title:"예약 게시",desc:"일회성, 반복 및 시간대 인식 예약 및 자동 게시 지원"},multiPlatform:{title:"다중 플랫폼 배포",desc:"한 번 설정하고 여러 채널에 자동 동기화 및 게시"},smartTime:{title:"스마트 시간 추천",desc:"도달률을 최대화하기 위해 과거 데이터에 기반한 최적의 게시 시간 추천"},sse:{title:"스트리밍 작업 (SSE)",desc:"점진적 결과 및 취소 지원으로 실시간 작업 생성 스트리밍"},taskManagement:{title:"작업 관리",desc:"작업 생성/중지/보기/삭제, 평가 및 댓글; 작업 전달 및 복제 지원"},workflow:{title:"확장 가능한 워크플로우",desc:"복잡한 자동화를 연결하기 위한 다단계 파이프라인 및 사용자 정의 액션 핸들러 지원"},videoUnderstanding:{title:"동영상 이해",desc:"감정, 인물 및 이벤트를 자동 인식하여 태그 및 챕터 생성"},report:{title:"리포팅 & 인사이트",desc:"검토 및 최적화를 위한 게시 성과 및 성장 제안 자동 생성"},commentAssistant:{title:"댓글 & DM 어시스턴트",desc:"참여도를 높이기 위한 자동 답변 제안 및 일괄 답변 템플릿 생성"},audienceInsight:{title:"오디언스 인사이트",desc:"주제 및 타겟팅을 안내하는 오디언스 프로필 및 콘텐츠 선호도 분석 제공"}}},F={prompts:t,badge:n,title:e,titleHighlight:s,subtitle:i,applyButton:l,collapseButton:o,expandButton:a,expandCount:c,appliedToast:d,loadedAll:r,promptsCount:p,noResults:m,tryOtherKeywords:g,modal:u,badges:h,categories:y,filters:b,apply:f,agentFeatures:T};export{T as agentFeatures,d as appliedToast,f as apply,l as applyButton,n as badge,h as badges,y as categories,o as collapseButton,F as default,a as expandButton,c as expandCount,b as filters,r as loadedAll,u as modal,m as noResults,t as prompts,p as promptsCount,i as subtitle,e as title,s as titleHighlight,g as tryOtherKeywords};
